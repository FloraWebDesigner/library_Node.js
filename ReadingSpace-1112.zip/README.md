# Library CMS Project

## Main source: Google Book API
## Others: openlibrary, weather, color, audio, image...


## Secured settings using .env
1. mongoDB database.
2. API keys.

## To run
1. Modify the .env file values to ones which reflect app settings.

